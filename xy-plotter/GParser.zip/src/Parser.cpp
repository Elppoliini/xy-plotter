/*
 * Parser.cpp
 *
 *  Created on: 22 Sep 2020
 *      Author: johan
 */

#include "Parser.h"
#include "ITM_write.h"

Parser::Parser() {
	// TODO Auto-generated constructor stub

}

Parser::~Parser() {
	// TODO Auto-generated destructor stub
}

void Parser::read(char* str_) {
	str = str_;
	divideString();
}
void Parser::print(){
	for (auto i = commands.begin(); i != commands.end(); ++i){
		std::string temp= *i;
		ITM_write(temp.c_str());
		ITM_write(" ");
	}
}

void Parser::divideString(){
	// check that the code includes only one line change other = garbage
	size_t pos = 0;
	std::string tempStr;
	std::string token;
	if((pos = str.find('\n')) != std::string::npos) {
		str = str.substr(0, pos);
		str += "\n";
	}
	//  Divide the string by space and add it to a vector
	tempStr = str;
	pos = 0;
	while ((pos = tempStr .find(' ')) != std::string::npos) {
		token = tempStr .substr(0, pos);
		tempStr.erase(0, pos + 1);
		commands.push_back(token);
	}
	commands.push_back(tempStr);
	print();
}

std::vector<std::string> Parser::getCommandLine(){
	return commands;
}

